package com.example.CommerceBankProject.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AccountErrorNotFoundException extends RuntimeException {
    public AccountErrorNotFoundException(String message) {
        super(message);
    }
}
