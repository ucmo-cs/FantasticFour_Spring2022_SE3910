package com.example.CommerceBankProject.controller;

import com.example.CommerceBankProject.domain.Account;
import com.example.CommerceBankProject.domain.Login;
import com.example.CommerceBankProject.repository.AccountRepository;
import com.example.CommerceBankProject.service.AccountService;
import com.example.CommerceBankProject.service.SecurityService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@CrossOrigin
@RequiredArgsConstructor
@RestController
public class AccountController{
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private AccountService accountService;

    @Autowired
    private SecurityService securityService;

    //private final AccountService accountService;
    @GetMapping("/get_accounts")
    public List<Account> getAllUsers(){
        return accountRepository.findAll();
    }
    //test
    /*@GetMapping("/hello")
    public String HelloWorld(){
        return "Hello World";
    }*/
    //creation of accounts
    @PostMapping("/account")
    public ResponseEntity<?> save (@RequestBody Account account){
            return new ResponseEntity<>(accountService.create(account), HttpStatus.CREATED);
    }
    @PostMapping("/account_admin")
    public ResponseEntity<?> saveAdminAccount (@RequestBody Account account){
        return new ResponseEntity<>(accountService.createAdmin(account), HttpStatus.CREATED);
    }
    @GetMapping("/account/{id}")
    public ResponseEntity<Account> getUser(@PathVariable String id) {
        Optional<Account> account = accountRepository.findById(id);
        if (!account.isPresent()){
            throw new AccountErrorNotFoundException(String.format("ID[%d] not found", id));
        }
        return new ResponseEntity(account, HttpStatus.OK);
    }

    //Login feature
    @CrossOrigin
    @PostMapping(path = "/login")
    public ResponseEntity<Map<String,Object>> validateUserLogin(@RequestBody Login login) {
        //System.out.println("Login Server TEST");
        //System.out.println(login.getUsername());
        //System.out.println(login.getPassword());
        Optional<Account> account = accountRepository.findById(login.getUsername());

        String token = securityService.createToken(login.getUsername(),(1*1000*10));
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("token", token);
        map.put("accountid", login.getUsername());
        map.put("usertype", account.get().getUsertype());

        System.out.println("validation" + accountService.validateUserLogin(login));

        if (accountService.validateUserLogin(login))
            return ResponseEntity.status(200).body(map);

        return ResponseEntity.status(400).body(null);
    }
    //deletes an account, no "verification" uses id from account table to delete
    //said account
    //Use: localhost:8080/accounts/ID Number
    /*@DeleteMapping(value ="/accounts/{id}")
    public ResponseEntity<?>remove(@PathVariable("id") String id) throws ClassNotFoundException {
        return new ResponseEntity<>(accountService.deleteAccount(String.valueOf(Long.valueOf(id))), HttpStatus.OK);
    }*/
    //Lists all accounts in a primitive format
    //Use: localhost:8080/accounts
    @GetMapping("/accounts")
    public ResponseEntity<?> findAll()
    {return new ResponseEntity<>(accountService.findAll(), HttpStatus.OK);}
    //"Accept" button handler first num parameter requires a
    //"approver" denoted in account table in the "USERTYPE" column == TRUE
    //(false equals normal user)
    //this sets a project to the status of approved status of '1'
    //'0' is default for pending and '-1' will be used for denied
    //use for this goes something like:
    // localhost:8080/accept/approver account id/projectid(found in 'PROJECTID' in Project table)
    @PatchMapping("/accept/{num}/{num2}")
    public ResponseEntity<?>accept(@PathVariable("num") String accId,
                                   @PathVariable("num2") Long projectId) {
        return new ResponseEntity<>(accountService.accepter
                (accId,projectId), HttpStatus.OK);
    }
    //same function as above, except it changes status of project to '-1'
    //requires 'approver' account id
    @PatchMapping("/deny/{num1}/{num2}")
    public ResponseEntity<?> deny(@PathVariable("num1") String accId,
                                  @PathVariable("num2") Long projectId){
        return new ResponseEntity<>(accountService.deny(accId, projectId), HttpStatus.OK);
    }
}

