package com.example.CommerceBankProject.controller;

import com.example.CommerceBankProject.domain.OpenSource;
import com.example.CommerceBankProject.service.OpenSourceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RequiredArgsConstructor
@RestController
public class OpenSourceController {
    private final OpenSourceService openSourceService;
    //Returns all open sources with specified column type 'STATUS' of specified number
    // example:
    //localhost:8080/open_sources/-1 | 0 | 1
    /*@GetMapping("/open_sources/{status}")
    public ResponseEntity<?> findAllOpenSourcesStatus(@PathVariable int status) throws Exception
    {return new ResponseEntity<>(openSourceService.listInProgressOpenSource(status), HttpStatus.OK);}*/
    //Creates an open source with specified account ID using ID from account table
    // Must be used in conjunction with Postman
    @PostMapping("/open_sources/create/{accountId}")
    public ResponseEntity<?> saveOpenSource
            (@RequestBody OpenSource openSource, @PathVariable String accountId)
            throws ClassNotFoundException {
        return new ResponseEntity<>(openSourceService.createOpenSource(openSource,
                        accountId), HttpStatus.CREATED);
    }
    //Works similarly to account delete
    // Deletes a specified project via first argument followed by the account number
    //that requested the project. PROJECT MUST MATCH ITS FOREIGN KEY TO ACCOUNT ID IN ACCOUNT TABLE
    // use: localhost:8080/open_sources/delete/PROJECTID/ACCOUNT ID
    @DeleteMapping("/open_sources/{projnumber}")
    public ResponseEntity<?> deleteOpenSource
            (@PathVariable("projnumber") Long openSourceId) throws ClassNotFoundException {
        return new ResponseEntity<>(openSourceService.deleteOpenSource
                (openSourceId), HttpStatus.OK);
    }
    //for getting project info by project id
    @GetMapping("/open_sources_by_projectid/{proj_num}")
    public ResponseEntity<?> findByProjectID(@PathVariable("proj_num") Long ProjectID){
        return new ResponseEntity<>(openSourceService.findByProjectID(ProjectID), HttpStatus.OK);
    }
    //
    //Various sorting mapping
    //
    //Returns all open sources as well as the
    //account that created the project
    @GetMapping("/open_sources")
    public ResponseEntity<?> findAllOpenSources(){return new ResponseEntity<>
            (openSourceService.findAllOpenSource(), HttpStatus.OK);}
    @GetMapping("/open_sources_name_asc")
    public ResponseEntity<?> SortByNameAsc(){return new ResponseEntity<>
            (openSourceService.SortByNameAsc(), HttpStatus.OK);}
    @GetMapping("/open_sources_name_desc")
    public ResponseEntity<?> SortByNameDesc(){return new ResponseEntity<>
            (openSourceService.SortByNameDesc(), HttpStatus.OK);}
    @GetMapping("/open_sources_status_asc")
    public ResponseEntity<?> SortByStatusAsc(){return new ResponseEntity<>
            (openSourceService.SortByStatusAsc(), HttpStatus.OK);}
    @GetMapping("/open_sources_status_desc")
    public ResponseEntity<?> SortByStatusDesc(){return new ResponseEntity<>
            (openSourceService.SortByStatusDesc(), HttpStatus.OK);}
    @GetMapping("/open_sources_daterequested_asc")
    public ResponseEntity<?> SortByDateRequestedAsc(){return new ResponseEntity<>
            (openSourceService.SortByDateRequestedAsc(), HttpStatus.OK);}
    @GetMapping("/open_sources_daterequested_desc")
    public ResponseEntity<?> SortByDateRequestedDesc(){return new ResponseEntity<>
            (openSourceService.SortByDateRequestedDesc(), HttpStatus.OK);}
}
