package com.example.CommerceBankProject.repository;

import com.example.CommerceBankProject.domain.OpenSource;
import org.aspectj.apache.bcel.classfile.Module;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OpenSourceRepository extends JpaRepository<OpenSource,Long> {
    //specifies how the listing of findAllByStatus in open source service will be done
    //in this case data will only be selected if status is == to given status
    List<OpenSource> findAllByStatus(int status);
    OpenSource findByProjectID(Long projectID);
    //sorting
    List<OpenSource> findByOrderByProjectNameAsc();
    List<OpenSource> findByOrderByProjectNameDesc();
    List<OpenSource> findByOrderByStatusAsc();
    List<OpenSource> findByOrderByStatusDesc();
    List<OpenSource> findByOrderByDateRequestedAsc();
    List<OpenSource> findByOrderByDateRequestedDesc();
}
