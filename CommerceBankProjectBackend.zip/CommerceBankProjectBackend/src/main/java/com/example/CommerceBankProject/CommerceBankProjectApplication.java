package com.example.CommerceBankProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceBankProjectApplication {
	public static void main(String[] args) {
		SpringApplication.run(CommerceBankProjectApplication.class, args);
	}

}
