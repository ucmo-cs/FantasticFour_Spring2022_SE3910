package com.example.CommerceBankProject.service;

import com.example.CommerceBankProject.domain.Account;
import com.example.CommerceBankProject.domain.OpenSource;
import com.example.CommerceBankProject.repository.OpenSourceRepository;
import com.example.CommerceBankProject.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.aspectj.apache.bcel.classfile.Module;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Service
public class OpenSourceService {
    private final OpenSourceRepository openSourceRepository;
    private final AccountRepository accountRepository;
    @Transactional
    public OpenSource createOpenSource(OpenSource openSource, String accountId) throws ClassNotFoundException {
        Account acc = accountRepository.findById((accountId)).orElseThrow(()
                -> new ClassNotFoundException("No account with id: " + accountId));
        openSource.setAccount(acc);
        String pattern = "dd MMM yyyy HH:mm:ss";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        openSource.setDateRequested(date);
        openSource.setStatus("Pending");
        return openSourceRepository.save(openSource);
    }
    @Transactional
    public Map<String, Boolean> deleteOpenSource(@PathVariable(value = "id") Long openSourceId)
            throws ClassNotFoundException {
        OpenSource openSource = openSourceRepository.findById(openSourceId)
                .orElseThrow(() -> new ClassNotFoundException("Open Source not found for this id :: " + openSourceId));
        Map<String, Boolean> response = new HashMap<>();
            openSourceRepository.delete(openSource);
            response.put("Open source deleted", Boolean.TRUE);
        return response;
    }
    //finding project by project ID
    public OpenSource findByProjectID(@PathVariable Long status ){
        return openSourceRepository.findByProjectID(status);}
    //default sort
    public List<OpenSource> findAllOpenSource(){
        return openSourceRepository.findAll();
    }

    public List<OpenSource> listInProgressOpenSource(@PathVariable int status) throws Exception {
        if(status <= 1 && status >= -1)
            return openSourceRepository.findAllByStatus(status);
        else
            throw new Exception("Arguments out of bounds");
    }
    //sorting
    public List<OpenSource> SortByNameAsc() {return openSourceRepository.findByOrderByProjectNameAsc();}
    public List<OpenSource> SortByNameDesc() {
        return openSourceRepository.findByOrderByProjectNameDesc();
    }
    public List<OpenSource> SortByStatusAsc(){return openSourceRepository.findByOrderByStatusAsc();}
    public List<OpenSource> SortByStatusDesc(){return openSourceRepository.findByOrderByStatusDesc();}
    public List<OpenSource> SortByDateRequestedAsc(){return openSourceRepository.findByOrderByDateRequestedAsc();}
    public List<OpenSource> SortByDateRequestedDesc(){return openSourceRepository.findByOrderByDateRequestedDesc();}
}
