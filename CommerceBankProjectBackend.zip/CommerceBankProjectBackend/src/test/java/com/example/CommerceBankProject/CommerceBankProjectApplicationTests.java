package com.example.CommerceBankProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceBankProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
